package com.swhyd.stamps;

import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class pizzacorner extends Activity {

	public static ArrayList<Integer> mpzclist = new ArrayList<Integer>();
	public static int i = 0;

	String position = "1";
	String city = "";
	String weather = "";
	String temperature = "";
	String windSpeed = "";
	String iconfile = "";
	ImageButton imgWeatherIcon;

	TextView tvcity;
	TextView tvtemp;
	TextView tvwindspeed;
	TextView tvCondition;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		try {
			String message = null;
			setContentView(R.layout.pizzacorner);
			GridView gridview = (GridView) findViewById(R.id.gridView1);

			// handle for the UI elements
			imgWeatherIcon = (ImageButton) findViewById(R.id.imageButtonAlpha);
			// Text fields
			tvcity = (TextView) findViewById(R.id.textViewCity);
			tvtemp = (TextView) findViewById(R.id.textViewTemperature);
			tvwindspeed = (TextView) findViewById(R.id.textViewWindSpeed);
			tvCondition = (TextView) findViewById(R.id.textViewCondition);

			// Get position to display
			Intent i = getIntent();
			int count = 0;
			

			this.position = i.getStringExtra("position");
			this.city = i.getStringExtra("city");
			this.iconfile = i.getStringExtra("icon");			
		

			String uri = "drawable/" + "dsnowing";
			int imageBtnResource = getResources().getIdentifier(uri, null,
					getPackageName());
			Drawable dimgbutton = getResources().getDrawable(imageBtnResource);

			
			// thumb_image.setImageDrawable(image);
			imgWeatherIcon.setImageDrawable(dimgbutton);

			gridview.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> parent, View v,
						int position, long id) {
					Toast.makeText(pizzacorner.this, "" + position,
							Toast.LENGTH_SHORT).show();
				}
			});

			Intent intent = getIntent();

			message = intent.getStringExtra("SCANRES");

			if (message != null)
				scancode(intent, gridview);
			else {
				Object[] mStringArray = mpzclist.toArray();
				ImageAdapter temp = new ImageAdapter(this, mStringArray);
				gridview.setAdapter(temp);
				temp.notifyDataSetChanged();
			}
			
			
			for (int p = 1; p <= mpzclist.size(); p++)
				count++;

			this.temperature = "" + count;

			// text elements
			tvcity.setText(city);
			tvtemp.setText(temperature);

		} catch (Exception ex) {
			Log.e("Error", ex.getMessage());
		}
	}

	public void scancode(Intent intent, GridView gridview) {
		String message = intent.getStringExtra("SCANRES");

		mpzclist.add(R.drawable.android_platform);
		Object[] mStringArray = mpzclist.toArray();

		ImageAdapter temp = new ImageAdapter(this, mStringArray);
		gridview.setAdapter(temp);
		temp.notifyDataSetChanged();

	}

}
