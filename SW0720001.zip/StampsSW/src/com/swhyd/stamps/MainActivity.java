package com.swhyd.stamps;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.dm.zbar.android.scanner.ZBarConstants;
import com.dm.zbar.android.scanner.ZBarScannerActivity;

import net.sourceforge.zbar.Symbol;

public class MainActivity extends Activity {

	private static final int ZBAR_SCANNER_REQUEST = 0;
	private static final int ZBAR_QR_SCANNER_REQUEST = 1;

	// XML node keys
	static final String KEY_TAG = "weatherdata"; // parent node
	static final String KEY_ID = "id";
	static final String KEY_CITY = "city";
	static final String KEY_TEMP_C = "tempc";
	static final String KEY_TEMP_F = "tempf";
	static final String KEY_CONDN = "condition";
	static final String KEY_SPEED = "windspeed";
	static final String KEY_ICON = "icon";

	// List items
	ListView list;
	BinderData adapter = null;
	List<HashMap<String, String>> StoreDataCollection;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		ListView lv = (ListView) findViewById(R.id.listView1);

		try {

			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(getAssets().open("storedata.xml"));

			StoreDataCollection = new ArrayList<HashMap<String, String>>();

			// normalize text representation
			doc.getDocumentElement().normalize();

			NodeList weatherList = doc.getElementsByTagName("storedata");

			HashMap<String, String> map = null;

			for (int i = 0; i < weatherList.getLength(); i++) {

				map = new HashMap<String, String>();

				Node firstWeatherNode = weatherList.item(i);

				if (firstWeatherNode.getNodeType() == Node.ELEMENT_NODE) {

					Element firstWeatherElement = (Element) firstWeatherNode;
					// -------
					NodeList idList = firstWeatherElement
							.getElementsByTagName(KEY_ID);
					Element firstIdElement = (Element) idList.item(0);
					NodeList textIdList = firstIdElement.getChildNodes();
					// --id
					map.put(KEY_ID, ((Node) textIdList.item(0)).getNodeValue()
							.trim());

					// 2.-------
					NodeList cityList = firstWeatherElement
							.getElementsByTagName(KEY_CITY);
					Element firstCityElement = (Element) cityList.item(0);
					NodeList textCityList = firstCityElement.getChildNodes();
					// --city
					map.put(KEY_CITY, ((Node) textCityList.item(0))
							.getNodeValue().trim());

					// 3.-------
					NodeList tempList = firstWeatherElement
							.getElementsByTagName(KEY_TEMP_C);
					Element firstTempElement = (Element) tempList.item(0);
					NodeList textTempList = firstTempElement.getChildNodes();
					// --city
					map.put(KEY_TEMP_C, ((Node) textTempList.item(0))
							.getNodeValue().trim());

					// 4.-------
					NodeList condList = firstWeatherElement
							.getElementsByTagName(KEY_CONDN);
					Element firstCondElement = (Element) condList.item(0);
					NodeList textCondList = firstCondElement.getChildNodes();
					// --city
					map.put(KEY_CONDN, ((Node) textCondList.item(0))
							.getNodeValue().trim());

					// 5.-------
					NodeList speedList = firstWeatherElement
							.getElementsByTagName(KEY_SPEED);
					Element firstSpeedElement = (Element) speedList.item(0);
					NodeList textSpeedList = firstSpeedElement.getChildNodes();
					// --city
					map.put(KEY_SPEED, ((Node) textSpeedList.item(0))
							.getNodeValue().trim());

					// 6.-------
					NodeList iconList = firstWeatherElement
							.getElementsByTagName(KEY_ICON);
					Element firstIconElement = (Element) iconList.item(0);
					NodeList textIconList = firstIconElement.getChildNodes();
					// --city
					map.put(KEY_ICON, ((Node) textIconList.item(0))
							.getNodeValue().trim());

					// Add to the Arraylist
					StoreDataCollection.add(map);
				}
			}

			BinderData bindingData = new BinderData(this, StoreDataCollection);

			list = (ListView) findViewById(R.id.listView1);

			Log.i("BEFORE", "<<------------- Before SetAdapter-------------->>");

			list.setAdapter(bindingData);

			Log.i("AFTER", "<<------------- After SetAdapter-------------->>");

			// Click event for single list row
			list.setOnItemClickListener(new OnItemClickListener() {

				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {

					Intent i = new Intent();

					if (position == 0) {
						i = new Intent(MainActivity.this, subway.class);
						i.setClass(MainActivity.this, subway.class);
					} else if (position == 1) {
						i = new Intent(MainActivity.this, coffeeday.class);
						i.setClass(MainActivity.this, coffeeday.class);
					} else if (position == 2) {
						i = new Intent(MainActivity.this, barista.class);
						i.setClass(MainActivity.this, barista.class);
					} else if (position == 3) {
						i = new Intent(MainActivity.this, dominos.class);
						i.setClass(MainActivity.this, dominos.class);
					} else if (position == 4) {
						i = new Intent(MainActivity.this, pizzacorner.class);
						i.setClass(MainActivity.this, pizzacorner.class);
					}

					// parameters
					i.putExtra("position", String.valueOf(position + 1));

					/*
					 * selected item parameters 1. City name 2. Weather 3. Wind
					 * speed 4. Temperature 5. Weather icon
					 */
					i.putExtra("city",
							StoreDataCollection.get(position).get(KEY_CITY));
					i.putExtra("weather", StoreDataCollection.get(position)
							.get(KEY_CONDN));
					i.putExtra("windspeed", StoreDataCollection.get(position)
							.get(KEY_SPEED));
					i.putExtra("temperature", StoreDataCollection.get(position)
							.get(KEY_TEMP_C));
					i.putExtra("icon",
							StoreDataCollection.get(position).get(KEY_ICON));

					// start the sample activity
					startActivity(i);
				}
			});

		}

		catch (IOException ex) {
			Log.e("Error", ex.getMessage());
		} catch (Exception ex) {
			Log.e("Error", "Loading exception");
		}
	}

	public void launchScanner(View v) {
		if (isCameraAvailable()) {
			Intent intent = new Intent(this, ZBarScannerActivity.class);
			startActivityForResult(intent, ZBAR_SCANNER_REQUEST);
		} else {
			Toast.makeText(this, "Rear Facing Camera Unavailable",
					Toast.LENGTH_SHORT).show();
		}
	}

	public void launchQRScanner(View v) {
		if (isCameraAvailable()) {
			Intent intent = new Intent(this, ZBarScannerActivity.class);
			intent.putExtra(ZBarConstants.SCAN_MODES,
					new int[] { Symbol.QRCODE });
			startActivityForResult(intent, ZBAR_SCANNER_REQUEST);
		} else {
			Toast.makeText(this, "Rear Facing Camera Unavailable",
					Toast.LENGTH_SHORT).show();
		}
	}

	public boolean isCameraAvailable() {
		PackageManager pm = getPackageManager();
		return pm.hasSystemFeature(PackageManager.FEATURE_CAMERA);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case ZBAR_SCANNER_REQUEST:
		case ZBAR_QR_SCANNER_REQUEST:
			if (resultCode == RESULT_OK) {
				Integer position = -1;
				String result = data.getStringExtra(ZBarConstants.SCAN_RESULT);
				Toast.makeText(this, "Scan Result = " + result,
						Toast.LENGTH_SHORT).show();
				Intent intent = null;

				if (result.trim().equalsIgnoreCase("SUB")) {
					position = 0;
					intent = new Intent(MainActivity.this, subway.class);
				} else if (result.trim().equalsIgnoreCase("CCD")) {
					position = 1;
					intent = new Intent(MainActivity.this, coffeeday.class);
				} else if (result.trim().equalsIgnoreCase("BST")) {
					position = 2;
					intent = new Intent(MainActivity.this, barista.class);
				} else if (result.trim().equalsIgnoreCase("DOM")) {
					position = 3;
					intent = new Intent(MainActivity.this, dominos.class);
				} else if (result.trim().equalsIgnoreCase("PZC")) {
					position = 4;
					intent = new Intent(MainActivity.this, pizzacorner.class);
				}

				intent.putExtra("SCANRES", result);

				if (result.trim().equalsIgnoreCase("SUB"))
					position = 0;
				else if (result.trim().equalsIgnoreCase("CCD"))
					position = 1;
				else if (result.trim().equalsIgnoreCase("BST"))
					position = 2;
				else if (result.trim().equalsIgnoreCase("DOM"))
					position = 3;
				else if (result.trim().equalsIgnoreCase("PZC"))
					position = 4;

				intent.putExtra("position", String.valueOf(position + 1));
				intent.putExtra("city",
						StoreDataCollection.get(position).get(KEY_CITY));
				intent.putExtra("weather", StoreDataCollection.get(position)
						.get(KEY_CONDN));
				intent.putExtra("windspeed", StoreDataCollection.get(position)
						.get(KEY_SPEED));
				intent.putExtra("temperature", StoreDataCollection
						.get(position).get(KEY_TEMP_C));
				intent.putExtra("icon",
						StoreDataCollection.get(position).get(KEY_ICON));

				startActivity(intent);

			} else if (resultCode == RESULT_CANCELED && data != null) {
				String error = data.getStringExtra(ZBarConstants.ERROR_INFO);
				if (!TextUtils.isEmpty(error)) {
					Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
				}
			}
			break;
		}
	}
}
