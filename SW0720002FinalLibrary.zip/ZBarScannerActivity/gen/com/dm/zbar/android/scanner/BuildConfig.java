/** Automatically generated file. DO NOT MODIFY */
package com.dm.zbar.android.scanner;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}